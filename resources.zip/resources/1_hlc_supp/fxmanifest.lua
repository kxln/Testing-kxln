-- Generated with Durty Cloth Tool v4.0.0.0 (https://gta.clothing)

fx_version 'cerulean'
game { 'gta5' }

author 'Highlife'
files {
  'mp_m_freemode_01_mp_m_1hlcsupp_shop.meta',
  'mp_f_freemode_01_mp_f_1hlcsupp_shop.meta',
  'pedalternatevariations.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_1hlcsupp_shop.meta'
data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_1hlcsupp_shop.meta'
data_file 'ALTERNATE_VARIATIONS_FILE' 'pedalternatevariations.meta'