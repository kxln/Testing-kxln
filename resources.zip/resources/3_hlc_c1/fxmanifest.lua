-- Generated with Durty Cloth Tool v4.0.0.0 (https://gta.clothing)

fx_version 'cerulean'
game { 'gta5' }

files {
  'mp_m_freemode_01_mp_m_3hlcc1_shop.meta',
  'mp_f_freemode_01_mp_f_3hlcc1_shop.meta',
  'pedalternatevariations.meta',
  'highlife_clothing_overlays.xml',
  'facial_overlays.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_3hlcc1_shop.meta'
data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_3hlcc1_shop.meta'
data_file 'ALTERNATE_VARIATIONS_FILE' 'pedalternatevariations.meta'
data_file 'PED_OVERLAY_FILE' 'highlife_clothing_overlays.xml'
data_file 'PED_OVERLAY_FILE' 'facial_overlays.meta'