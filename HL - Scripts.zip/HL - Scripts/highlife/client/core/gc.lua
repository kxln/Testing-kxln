HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/gc.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\
6L)\30V`6?\15\8\17\0187K\27\30\11\\G\22?\9\127oeB`vBSvM3\23+\8C\3\0114@Hol[\20bW,R\13D\31b+77\24>!\\\0055\0318\0031C\16\26\1(\14\14\16\0117]o0+\23\14BX)76+\5p/\1C;\25uG6L\27J\0075\4\13\7\5&^.\5\
V\8TPm;,0\31$a[Js`_oOb\26GD9\7\13\14\0031M(\22\26U\14V\29b\127 *\29<#\17\23}DXh \5SC"
}
