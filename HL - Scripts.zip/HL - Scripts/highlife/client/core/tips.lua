HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/tips.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\25<\0186E[\31\5PELB47^&\4\28R\29e\17)3kb61+\23\0196\12,6,\27DMHz[WRVb\9cW\14B\1R\12#7-mXZk_CS\0043B\13\2P\2(3\14\4L6>X6\18\26\25<Y\23=\31\"(\20 *\19\26\14\4%\17e\
Y\14D\18\1\6\
*;_*Y8[\14H\12#5&\127652ZD2\2 \0166L\30JXzZTRF&Q*\25b\26B\17qC1%e\31?2R+3\
=.,\13RD46\9\24\7\20|q&\19\13\127:uX>0&+{}kRjSd\27\0131\2Q\3\7;\28\8\13\8\13x-\24\30R\"P\8b+77\24>!\\\0055\0318\0031C\16\20\29$<\8\18\24%GuWMDH\29X\0097-#\0247h&\
*\30{/ \24D\11\3?\27:\15\7&Qa\5\9Y\11^\21b{\0*\0316/\21M\14\4%\17k&R\25\23;\15\4\17O\15\16f}E\26O8q/6'O\\}f{\0064\9_OhKR\4\0s"
}
