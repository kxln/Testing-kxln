HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/epoch_time.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\8%\13&\3h\30\0137\13O\14\01933bZHs*}=\30\29"
}
