local function DecodeChunk(data, salt)
	local salt_bytes, parts = { string.byte(salt, 1, -1) }, {}
	local salt_length, length = #salt_bytes, #data

	for start = 1, length, 4096 do
		local bytes = { string.byte(data, start, math.min(start + 4095, length)) }

		for k = 1, #bytes do
			bytes[k] = bytes[k] ~ salt_bytes[(start + k - 2) % salt_length + 1]
		end

		parts[#parts + 1] = string.char(table.unpack(bytes))
	end

	return table.concat(parts)
end

CreateThread(function()
	repeat Wait(1) until _G['HGS']

	local salt = _G['HGS']
	local chunks = HighLifeObfChunks or {}

	if HighLife.Settings.Development then return false end

	print(("^2[HighLife]^0 Loading %s chunks"):format(#chunks))

	for index, chunk in ipairs(chunks) do
		local started = GetGameTimer()

		local decoded = DecodeChunk(chunk.data, salt)
		local fn, compileError = load(decoded, "@" .. chunk.name)

		if not fn then
			print(("^1[HighLife]^0 Compile failed in %s: %s"):format(chunk.name, compileError))
			return
		end

		local ok, runtimeError = pcall(fn)

		if not ok then
			print(("^1[HighLife]^0 Runtime failed in %s: %s"):format(chunk.name, runtimeError))
			return
		end

		local took = GetGameTimer() - started

		if took > 500 then
			print(("^3[HighLife]^0 Slow load: %s took %sms"):format(chunk.name, took))
		end
	end

	-- luacheck: ignore
	_G['HighLifeObfLoaded'] = true

	print("^2[HighLife]^0 Finished loading chunks")
end)