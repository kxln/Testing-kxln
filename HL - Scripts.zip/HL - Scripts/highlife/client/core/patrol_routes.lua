HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/patrol_routes.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\0294\0227\4[5\0225\29\21\7\21|U:\22bt\29T\25>=\23-\0035'\22K<\24;\0011\2X\4Lsekk\0=Ko\5\7B\27T'$9. ]p4\29\22.\8\
\6$\31VJ\0134H\17\3\15 Jg4\7Y\9X\31d\8\"1\3?* \12/\0250\17lKS\5iPah1\3&L?'\9C\29^\20\024761\20x4\29\22.\8\
\12$\6RFD(\7\20\22\3\13].\3\9\30b;q/6'H{5(\22J"
}
