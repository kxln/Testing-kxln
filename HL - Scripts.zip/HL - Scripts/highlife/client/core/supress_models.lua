HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/supress_models.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\30 \0187\14D\25;7\7\5\7\
!\23#\2\9==T\31#+7 \3\4/\17\8rJ\6\0235\27E\15\23)%\14\6\3>Jh[H\2_\1Hfx%0\03132\27\0124E|oObQ\5\22z\1\\SJr\26\12\24\6Q\6VV\25-35\00355\1\6> :\6 \7DJ\0005ekko\1\\;!\13_\6R\20/\21,!\20<\15\0010/\29%\16 \24D\15\0r+\14\12\0;^a$\29G\31C\0299+&!<?\"\23\15)6<?iKY\5\16z/\13\13\0043U\28\3\9C\
\31:+<\1*\8#o\127iS\8;\6HaR\4\0s"
}
