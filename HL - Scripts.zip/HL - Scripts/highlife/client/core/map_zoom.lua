HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/map_zoom.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u\0004\18\26\17X\5\9t\4\20\3l>V,\22\4\23\"P\8\0167,(512\19CgM.hL0\0077DgH\26ho[C \24\5d\12P\20/x~eA~\127DOPd\\\24*\4Z9\20?\13\5B[r\9aND=f8\11)*,)\29\0036\23\6>MhBuE\7RHPah\22\15>\\<WU\23\20IXwxskA|f\11CgMeLu\22=c\25vbh9W\15\25rW\19=f8\2%7.\22\0181*\23CgMdLsG=cm \7\14\0155\"\\*\19H\
O\1VstILx#%\0\0126\1\6\18 \14SJYzXOR^~3F~\28^\3T\11jec>\9p{RSt]yB<K\
JTtX\28ho/\21E~3\0052\17Ej#ILx*)\29\14\9\0144\14 K\
J\\t^Mho[C \24\5d\31T\29.x~eA~\127^iSd&\0017\4[\0067*\13\4\6Fo\25\127YX\15C;qC,*)\20#fOC!\21u_e[\25ZHz\17A_Fb\23\127\
b>\18\29rC\3p\24Qmf\9iSd/\13*\6d\9\0056\13A_Fc\11aDD=f8\2%7.\22\0015#\22CgMeL|G=cm)\11\19\13\
>j?\18\13SO\12Xzvs}]ZO{\0233\0010\17eV\23\17\28zUARHb\21o\14H\
O\1Vz%IL\12|L{8n0u_e\16=cm \7\14\01551X#\18H\
O\3LdkoOxY<\29\0127>%\7 \15\23WDjFXNl[0<\20\26X\3]+:=&!QmfBMjUyhLbC\3\8?\27A_F)AoJH\7A\1Tj!cxQ`hB\30Pd(NObl_9zUA\25F\127\20o-'x\"n4\15\14\6\9.\23\9>%\5.\0267\0238r`mS\18\14\13\11\1Z.\27\13\23R\17M\127vsi{YO\8\0125\0\6\18 \14SJYzXORJX0F\4\11E\0]\20\25(& \21p{RSt\\yhLbC\3\8?\27A_F)AoJH\5A\1Tj!cxQahB\30Pd(NObl\\9zUA\25F\127\20o-'x\"n4\15\14\6\9.\25\8&&\8$\0260Ob>\16\0115\0052\1\7>\\oJH\3Z\1VztILx*)\29\14\9\0290\7!K\
JTtXMho[J,\5\7[\3b\8/='eLpv\\Rvg\\k1\2[\15\23zUA\25\30r\4oFF\7C\17\1ject_`;xj'A_k\30\\jJYz\19AOKrc\0008%h#t.\15\20\28\0020\28\
71\3g\\k?\4X\00779\9\13\7Fo\25{Y]\27e8q07,(\" #\23\7zPuRk[\27`mS\27\2\16\9>U\28\7\13R\11\17Ejhmu]ZO{\0233\0010\17eV\23\17\28zUARHb\21o\14H\
O\1Vz%IL\12|L{8b0u_e\16\23GIz2.-+\13u\
!-{0v9\6\20\6\23(\15\0113;\19 \0288\0a>c\0305\7\0121\0053U*WU\23^\0VztILx*)\29\14\9\0290\7!K\
JTtXMho[J,\5\7[\3b\8/='eLpv\\Svg\\k1\2[\15\23zUA\25\30r\4oEF\7C\17\1jecv_`;xj'A_\31Oat\24\1;\28\0046\14 \\.\19@Q\26_\27>1,+YyL{\0055\31u\9i\29\23\3\
z\24\0\11\20!\17\2\22\24m\0^\21\01497$Xp\"\29iSd\6\0071&V\26>5\7\12&\7&X\3\18\30R\3\25\19fx5k\11?)\03109\0129\7iKAD\0305\7\0121\0227\\+[HAAB\02787/)\" #\23\7vM#L1\2[\15\23t\16MB\16|M&\27\13DAHQ@Q&+\21Z#\28\7s"
}
