HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/core/_profiler.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^3)\0\6u2%\16*\13^\6\1(F\13\23\7Xq&\16\0{\6W\29d\0081*\0239*\23\17zPu\0258f=gn<\29\15\1\18;V!W ^\8Y4#>&k!\")\20\
6\8'X\22\31V\24\16r\24\19\13\0;U*(\6V\2TTj;!l|ZO\"\0175\11<\14 \25r\4\16?\0262\1\9\"\\g\7\26X\9X\20/\7-$\0285o\127iWg\\\1'C\30gnWbh2\20=_&\27\13E*I\17>\11 *\0015n[nP\8;\6"
}
