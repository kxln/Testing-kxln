HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/player/dropped_clothing.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^ *\19\26?\31z\0067\4G\26\1>7\2\14\9&Q&\25\15\25\3D\25@une\0215*\23\23?"
}
