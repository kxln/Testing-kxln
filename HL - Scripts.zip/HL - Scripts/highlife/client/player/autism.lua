HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/player/autism.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^ *\19\26?\31z\0030\31^\25\9t\4\20\3l\127\20o\19\13[\
E\29"
}
