HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/player/force_ped.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^ *\19\26?\31z\4*\25T\15;*\13\5L\
'XEZE\23\11T\20/,&"
}
