HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/player/damage_modifier.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^ *\19\26?\31z\6$\6V\13\1\5\5\14\6\0154P*\5F[\26Prguc!\20<#\6\6"
}
