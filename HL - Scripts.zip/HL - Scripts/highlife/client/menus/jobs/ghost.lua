HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/menus/jobs/ghost.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^=#\28\22)B?\13'\24\24\13\0125\27\21L\
'XEZE\23\11T\20/,&"
}
