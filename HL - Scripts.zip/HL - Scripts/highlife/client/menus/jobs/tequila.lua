HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/menus/jobs/tequila.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^=#\28\22)B?\13'\24\24\30\1+\29\8\14\7|U:\22b\26B\17\28/4&1\20"
}
