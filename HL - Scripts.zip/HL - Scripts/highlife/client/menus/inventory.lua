HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/menus/inventory.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^=#\28\22)B<\0123\14Y\30\11(\17O\14\01933bZHS\
]\29>="
}
