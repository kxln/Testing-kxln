HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/features/moonshining.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^6#\19\23/\0310\17j\6X\5\
)\0\8\12\15<^a\27\29Vec\29-101\20\"\8\23\23\31\0270\0121C\16\"\13=\0-\11\0007\3\28\31\1Y\6_\31p\8/$\0185\21\6\
6\1rKHav\14\0\31\30\4\12\18\26X!\19\4R\29\25_\0021$-=9 \23Y\9\5<\12,\5PP46\9\2\0075&P#\27O\27OW\13$;7,\30>n[nPd\1\16,\12P\15\22\9\13\19\20\3 |9\18\6CG\0220#?+\9\0246#H02\4;\11+\12\13:\8;\11\0041\18;U#PA:eT\22.q"
}
