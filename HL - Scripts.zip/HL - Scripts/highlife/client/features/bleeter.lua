HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/client/features/bleeter.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\20#=-1^6#\19\23/\0310\17j\9[\15\1.\13\19L\
'XEZE\23\29T\21%.&"
}
