HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/config/appearance_stores.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\23$>*\"^16\2\6;\0314\12&\14h\25\0165\26\4\17H>L.}E\26OR\16/;(6Q9 R\20?J'\7e\31_\15D)\13\19\20\3 \21o\22\6SOX\30j/&b\0035f\28\12.M:\12e\15R\28Hz\9\15\6F&Q*W\24V\27YX#+-b\5p2\26\6z\30!\3+\15V\24\0z\11\14\12\0;^o\7\9C\7\17P9=13\20\"f\7\16?\30u\1*\5Q\3\3\5\11\13\11\3<M\16\4\13E\25T\
j7-e\02990\23JWgxOe\30D\15\0z\28\14B\21&V?W\11X\1B\12+67)\8p4\23\18/\4'\11+\12\23\12\0136\13\18B\17;M'\30\6\23\27Y\29j;/,\20>2R\0128\11u\4*\7S\15\22Wb\8\4F\27J\11\2\24[\6R\17>!\21 \3#/\29\13rDu\3+\15\23B#?\28\"\13\8$X=_O^\28n\28/.diQw \19\15)\8rKeV\
JC<\9\13\17\3u\16o\22\6SOB\01281-\"_6/\28\7r\0090\0000\12\25\13\1.\1\15\4\9z\8fY\27X\26C\27/tcb\18?(\20\
=BrKe\31_\15\
Wbh\16\3&L=\25HQ\14]\11/UI \0314KxnP.:\12#\2PD%*\24\4\3\0203W,\18;C\0C\0299x~e\
]L{)?\0260\14)\14E\0197.\7\19\7Fo\0254zb>fs\0259=\0197\0243#R^z^`Rif=gnSa2\22\9 \\<WU\23\20<rCQJ\19\16>!\23\0156\0046\13eV\23\17iPahko\28X\"\18H\
O\22.+6$ \29</\17\12}AXhLb>c(5\11\0\22\15=W<WU\23\20<rCQJLx&#\17\0235\31fJh]\5[JbPSSRc\21oZZ\4_\31AzastC|fA[t]`Uu]\3CiPahko/\21B}a>f8:&13eLp=\127iSd\\kL8G\24\13.\13A_Fc\9czb>f8qC\27,)\30\"fOCj`_kLb>\23HWbhko[t*\25\29c\
I\12?*&eLp(\27\15v`_kLbJgnSa\28NkX0F$\13[\3e\1:=0eLp=\127iSd\\E\0\
E\25Cvekko[\30\12\31\9^\1\22TGRJLxw\
\23\5.,'\15bG:`mSaF0\0155Q;6\26ZH\29u@QJ8]]L{j\28\2'\1 \15~\30\0017\27A_F)4E~a>,Y\25#6cxQ+KxjSd\\/$\7RJYz\19lho[0F~[\0W\29u@QJLxYuJTWg\\kLbJFiPahko\20\\\"\22\4RO\12X1UILxYO{PmUyoOb>cmS[YUkX0F~aJC<rCQJ8]]L{jS!0\0041*E\7DgH\26ol[0F~%V\3TXwx8H{YO{jS\\XhLb>c\25vekko[0\9\18\5V\3TXwx8H{YO{jS\\XhLb>c\25vekko[Dczb>f8*#?+10\"+R^z\22XhLb>c);\4\4B[rBB}a>f8q{UILxYO\15OWg\\kLbq\15\9;\4\4B[rBB}a>f8q{UILxYO\15OWg\\kL\22\27gnSah'\7 JoJHLb;qCQJ\8\16<#R^z\22XhLb>cmkekko[02[e=f8qC\30&(\16<#R^z\22XhLb>cmkekko[02[e=f8q7UILx-Kxj'AXhL;[\11\23.\1\0021\19 ^*\5\17\23R\17\3GRJL315\0233(\0046\7eV\23_TjXMol_3F~$X\12P\12#7-6Qmf\9nPd\\k&\2C\19DgH\26ol[0F~\4X\12P\12#7-eLp0\23\0iEx[q[\25SWvHLQUj\23{CD\23\\\9Vs`ji|ZO{jS\30%\0131\24\23WD!ekko[0F\1\13T\\\25Uslsk@ajRNi[cLu]\27JWbFXZO~4E~a>f8\14/;pm\\ir@MbZyBhX\1XJi[MBUj\23vOA\27b;qCQJL\0075%AKwTaZkZ\15FDw[T[H`\13cW[\15A\8@ctNOxYO{\30Wg\\kL\22:`mS\21Mol[0\13\27\1GO\12X1UILxY\21\2\0173\0250BxK\6ZHWbhko\17V#\24\26\23R\17HGRJL\12]L{\30v`_k\7\
E\8\1(\27\9\13\22r\4o\12e=f8:++&\21\0039%\23CgMdRif=gnSa2\22\9 \\<WU\23\20<rCQJ\2\20>#\0\
9MhB>f=cmSa-\13\0053M&\24\6DO\12X1UILxYO{\21?\14fJhS\6^JiXYNF\127\8wDF\15]\2TjkukDf~[OWg\\kLb>\28\0019[ISUd\23wE^\27O\28I}h{kBgu^ChU{P|Z\30FiPahko[O*\20[\31B\0JrjmsAdjRNk\\dTk\\\2]Hz]O[_b\16czb>f8qC.&&BxwKPkC`SvG\23YShQOTQc\21oDY\25W\5LctNOxYO{j,\0086QmZ\5[VtPURJr\20{@Z\25V\3Ifxup_bvJJv`_kLb>c\18?\11RJKa\11aOP\2C\17U{mqkBa\127^Co[{Rr]\30FiPahko[O*\20[\31B\3OrvsrF|fDQhU{VsX\27JWjFW[S{\21B}a>f8q<= vYapFZt]bUiK\3RSnFUTU~\25{EF\1V\4QfUILxYO{\21?\14aJt[\15DSmPPVS~\25bF[\7^\31N~`zwG|f@Zt_dZ|X\6FDiFQKJ_3F~a>fG\29)lkhDet\\ZhXbPuG\23GQb[OVPb\8{CD\23[\0V~kstI`jRVt]|NHa>cmS\21Mol[0F~*[\6AXwx8H{YO{jS>%\16,\31RJYzYQNkX0F~a>,^\20%*cxQ`KxjSd\\\31Ha>cm'ekko/4E~\21\27b;q\0094,1\0259(\0210.\2'\7eV\23\17iPah \7!\\\31\5\1T\
\17Ejiti|ZKxjS>!\0137\14DJYz\19lho[0\8\18\6R\29X\27jec>|ZO{jS!:\1$\31^\5\
)H\\B\29_3F~a>fG\29)kkrG~\127COz@dQ|[\25ZHzZXLUj\16czb>f8qC.&&BxwCMl^gNe]\2[PtZSVJr\
\127YP\0X\24TGRJLxYO\4\0069^}Sw[\5DSkDAPQc\9aA_\27O\2OdjqwX|KxjSd\\k3\14TYLkZRLPf\15cWE\5^\8V~lsiQeu\\VoZ|NHa>cmSa\23\7\5a\17yFP\25_\8KfxqrDihDQcAuVtE\7R\\sDlho[0F~\30R\12\2P~j{kGir^CwUeRkZ\7\\HzZYLRk\8f[e=f8qCQ5 \18cnCUc[{P|Z\27JPbZXLUc\11cW\\\6A\1NyqoH{YO{jS\0270\1vC\26[RmFYTU~\25bEQ\15A\8NstcvI~qAPsAXhLb>cm,\13\2QN\127\14\127DF\0X\7TjurpC~tG[vMfTk_\6_Mvekko[0F\1\13T\\\25U{izv_dtKOz@bUwE\5\\VvHPTHa\11{^D:e8qCQJ3\0203uZNi\\bPk_\14\\HzYQV^|\8|DD\23^\8Vrnpl]]L{jSd\\\20 \8\4BIbZXLRc\
cWE\6_\6Kdoru]pwBMi_mKif=cmSah\20\0031\
gZY\3[\6V}atiQ}tFQtYcSiK\3RJbZQKJ_3F~a>fG\29)kkh@avCMo\\`NeY\0Z]t]QRJr\8vYY\7X\24TGRJLxYO\4\0069Y}SuR\1DSkDAPVb\23y@D\23B\5AdjqiQchBJv`_kLb>c\18?\11UJKc\8}EF\5_\29XgiwvF~pEOzX{PwG\23[JjAMol[0F~aA\
RKbirsD~rBSbZlNeF\3^\\tZUTS`\8cW^\1A\8M~ks}X|KxjSd\\k3\14TYLk_VZHd\0|@Z\1C\17K|ktkIg\127AZoAuQvE\15R\\j^TKJ_3F~a>fG\29)lkhDfq\\Uj[eS}G\23GQb]OP^j\1~OD\23\\\5V|`r}CdjRVt]|NHa>cmSa\23\7\5f\17bBZ\2A\2@~kz|]pkDSlCeW}^\14^Hz\\PLRa\9~N]\27O\6VzqoH{YO{jS\0270\1qC\3_ToFXVQ`\15y[H\26[\4I|vv|DbwGOzY{SrZ\0SQvHRLV{4E~a>fLTGRJLxY\4\30\
*MhB>f=cmSah1\22 P;\18H\
O\0HfUILxYO{ 5\1:\16eV\23ZiPahko/\21B}a>f85/66\17\20(2\7\17?MhB+\2[FiPekko[0\28\18\4[;H\8/+cxQ+KxjSd\\kb#V\30Cvekko[0FP)E\2B_fUILxYO{D\25\0054\11+L\27gnSahkoui.\25\28DH\29u@QJLxYa!\0115\8&Eif=cmSahE)$\\=\4\0^\29E_fUILxYO{D\15\0031\0077\24_\3\22.OMol[0F~\21:e8qC%NOxY;\127iS\16Xh8"
}
