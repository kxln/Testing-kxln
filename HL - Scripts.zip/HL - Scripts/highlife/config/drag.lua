HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/config/drag.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\23$>*\"^44\19\4t\1 \3OF\26J\0072\13\2\9\21rP)W\31RHC\29j,+ Q##\0\21?\31yB$\5SJ\13<H\22\7A \\o\25\7CO^\22j<&3]p'\28\7z\25=\7e\27V\30\12z\1\18\12A&\25;\31\13\23\28E\25$<\"7\21p%\29\13<\0042B5\
C\2Dr\27\4\16\0167Ko\2\27R\28\17\27%6%,\22\15%\30\
?\3!=6\14E\28\1(H\14\12F>P9\18A:e\28Uj-0 \21p2\29C)\25:\18e\8X\4\23.\9\15\22\
+\25=\18\25B\6C\17$?c#\24<#\1C-\4!\
,\5\23\30\12?H\2\14\0157W;W\7U\9\17\30%4' \3]L\27\5z$&&0\27[\3\0073\28\0244\3 J&\24\6\31F\17\25$<cm6521\0124\0274\16mL^\25;>\13\23EJr\30)\22\4D\
\22Qje~eV6'\30\16?J|B$\5SJ\23.\26\8\12\1|_&\25\12\31\11T\26??m\"\20$/\28\0055EdKk\24X\31\0229\13MBA1V!\17\1P@\22Qj,+ \31]L{\17?\25 \16+KQ\11\8)\13lh\3<]B}e=,^\22,1$k5\"'\21CgM.oOb{\11\29\30\7\22\12'<P\"WU\23\20<rCQ',\18$fOC}\0<\0176\13U\3U}Dlho[X!\30\5\23R\17_)(1\26\1%+\2\0002\8&\22\26\2S\6\1}ekk\27~4E~$V\22u\23=6\21 \0259%\30\6)MhB>f=cm\1/\4\22.3J'<\13NG\22\25':,tVy\27R^z\22XhLb>\19DgHLSHb\21B}a>fKXwxrkC|KxjSd'\0131K\
JUbXORkX0F\
D:e8q\17\31&1915\26(?\20}E$\6U\5V}A<B[rBB}a>fHXwxnw_dj\127iSd\\\24eV\23GTt]Mol[0F\5\7CO\12X{`skA]L{j'AXhLbl-\1. \0\17\14\25\\6_OV\2S\23y\127j\24Qmf\9nPd\\k<K\
JIhFUNkX0F~\18\23R\17Uzvvi|ZO{j(\2!BxK\6RTtXlho[Dczb>fj?/,\11$\0028\13\23\26rJ4\21tX\14MM\7H\\B\29_3F~aNO\12X{vsi|ZO{j MhBuE\4FiPahk\20=MoJH\6W\1VztNOxYO\27\16\5\0014\16\"\14h\28\0012\1\2\14\3r\4o\3\26B\
<rCQ>H{Y;\127i'"
}
