HighLifeObfChunks = HighLifeObfChunks or {}

HighLifeObfChunks[#HighLifeObfChunks + 1] = {
	name = "[highlife]/highlife/config/auction_house.lua",
	data = "Oh+Q\3\8?H!\
\0155Q#\30\14R@R\23$>*\"^13\17\0233\2;=-\4B\25\1t\4\20\3l\127\20o\20\0R\12Z\11j1%e\0065a\0\6z\25=\7e\24R\24\18?\26MB\7<]o\30\14\23\24T_8=c+\30$f\29\13z\0090\20iKV\4\0z\28\9\7F\"X;\31H^\28__>x7-\20p5\6\0024\0094\16!KT\5\
<\1\6B\0223M'W@D\
C\14/*c0\00255R\0005\0033\11\"4T\6\13?\6\21=\0217K9\18\26\23\0_X&15 X]L_Nz\24&\7!KC\5D)\28\14\18F1V!\4\28V\1E\0203x1 \0%/\0\
4\
u\4,\7R\25D-\1\21\
\15<\25;\31\13\23\12]\17/67e\0302 R\0055\0011\0077f=\3\2z!\18&\19\"U&\20\1C\22g\0298+**\31xoR\0024\9uJ\2\14C)\0114\30\0\16NuP<(\12R\25\22Tj\127%$\29##UJzPhBb\13V\6\23?OHB\7<]o\4\28E\6_\31d>*+\21x\"\23\1/\
{\5 \31^\4\0025@PKH!V:\5\11RC\17_)7-#\0247iUJz\25=\7+f=c\22?\28\20\16\8r_.\27\27Rb;\29$<NO|Z\5\29\13<\0042L\4\30T\30\0135\6)\13\19!\\oJHLb;q\25,\"7\0059(\21!3\9u_eZ\7ZTvekk*;J;'\26^\12T(/*  \31$fOChAXhL%X9\0056\0131\7\0201\\!\3H\
O\0TGRJ\19\0208/\17\15?)<\0175\7V\19,?\9\5\11\0085\25rW[\6_\31HfUIL'5.\27\0006\8\23\14*\8\\)\8;\27\18\7\21r\4o\12e=f8#{k\30eLp2\0\22?AXhLbl[P\7H\\B\18 L*[e=f8#{m\30eLp2\0\22?AXhLbl[R\7H\\B\18 L*[e=fLTGRJ\19\0208/\17\15?)<\0175\7V\01945\27\8\22\15=WoJHA\
RLbuu|I~tJVm[bNeF\1SRt_QQPc\
cW[\7A\7K\127ns|]puG[t]|NHa>8\0017\9\8\12\15<^\27\30\5R,^\20%*0eLp=\127iSd\14Qs[\0077DgHF\28\31,\30czb>fjNzh\30eLpa\12\12$JyoOb>1Rj5A_FuG=\9O:e8\5fUIL=95\6\
4\
\17\0237\
C\3\0114\27A_F)4E~alY\1X`xpu,p{RDi]u/,\5B\30\1)OMol_3F~3\4Y\1H\23x~eVaf:\12/\31rNHa>c?i^QRFx\25}*H\
O\22Jj\16,0\3#a^nPd\\9v]\7ZDpHR?Fo\25hDH\127\0D\
9\127oH{YO)Pl]eBoK\0017DgHFTF\26V:\5\27\16C<rGRJL*hpFSjM\127Bt6\23WD}YA&\7+\30czb>fj@|lsuQzf@>zPuEwKs\11\29)OMol[0\20O^\3_\1X`xp\24QmfUPz)4\0276L\27gnSa:ZPf\9\127WB\23[lXwxdqQ\20'\11\16}AXhLblRRnXQBLr\12\18WU\23H\4X\0149:6V|KxjS6mTq[\7JNz^<B[r\30yW,V\22B_fUILx\11~DWj]uHe\\jJYzOPB17\\$PD:e8\5fUIL!?5\27\0233\2;BxKA\15\7i@LT_e\23xAQ\7[\2Tjuu}B~~DSk]bNeX\7DSk[PUW{4E\
"
}
